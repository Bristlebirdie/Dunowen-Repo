<?php
	
	$Assets = new PerchAssets_Assets;
	$Assets->reindex();