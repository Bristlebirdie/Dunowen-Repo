<?php
	
	foreach($assets as $Asset) { 
		echo PerchAssets_Display::grid_item($Asset);
	}
