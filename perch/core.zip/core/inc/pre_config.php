<?php
	define('PERCH_DEVELOPMENT', 10);
	define('PERCH_STAGING', 	50);
	define('PERCH_PRODUCTION', 	100);
