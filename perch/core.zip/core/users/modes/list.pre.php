<?php

    $users   = $Users->get_grouped_listing();

?>