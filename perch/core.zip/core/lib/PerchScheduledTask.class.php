<?php

class PerchScheduledTask extends PerchBase
{
	protected $table  = 'scheduled_tasks';
    protected $pk     = 'taskID';
}

?>